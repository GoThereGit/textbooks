import './3d-force-graph.css';

export { default } from "./3d-force-graph.js";
